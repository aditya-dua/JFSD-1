package l1_introduction_to_hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration c = new Configuration();
		SessionFactory sf = c.configure("hbm.cfg.xml").buildSessionFactory();
		
		Session session = sf.openSession();
		System.out.println("DB Connection Success"+sf);
		
		Employee e = new Employee(0, "Aditya", 1000);
		
		Transaction tx = session.beginTransaction();
		
		session.save(e);
		
		session.flush();
		tx.commit();
		session.close();
		sf.close();
	}

}
